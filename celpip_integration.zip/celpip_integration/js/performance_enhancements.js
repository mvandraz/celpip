// Mejoras de rendimiento y compatibilidad para la aplicación CELPIP
document.addEventListener('DOMContentLoaded', function() {
    // Optimización de carga de recursos
    function lazyLoadResources() {
        // Cargar audio solo cuando sea necesario
        const audioElements = document.querySelectorAll('audio');
        audioElements.forEach(audio => {
            if (!audio.hasAttribute('data-src')) return;
            
            const section = audio.closest('section');
            if (!section) return;
            
            // Observador para cargar el audio cuando la sección sea visible
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const audioElement = entry.target.querySelector('audio[data-src]');
                        if (audioElement) {
                            audioElement.src = audioElement.getAttribute('data-src');
                            audioElement.removeAttribute('data-src');
                            audioElement.load();
                            observer.unobserve(entry.target);
                        }
                    }
                });
            }, { threshold: 0.1 });
            
            observer.observe(section);
        });
    }
    
    // Mejoras de accesibilidad
    function enhanceAccessibility() {
        // Añadir atributos ARIA para mejorar la accesibilidad
        document.querySelectorAll('button').forEach(button => {
            if (!button.hasAttribute('aria-label')) {
                button.setAttribute('aria-label', button.textContent.trim());
            }
        });
        
        // Mejorar contraste de colores para elementos importantes
        document.querySelectorAll('.timer').forEach(timer => {
            timer.style.color = '#d91e18'; // Rojo más oscuro para mejor contraste
        });
        
        // Añadir focus visible para navegación por teclado
        const style = document.createElement('style');
        style.textContent = `
            button:focus, a:focus, input:focus, textarea:focus {
                outline: 3px solid #3498db !important;
                outline-offset: 2px !important;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Optimización para dispositivos móviles
    function optimizeForMobile() {
        // Detectar si es dispositivo móvil
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        
        if (isMobile) {
            // Ajustar tamaños de fuente para mejor legibilidad en móviles
            document.body.classList.add('mobile-device');
            
            // Añadir estilos específicos para móviles
            const mobileStyles = document.createElement('style');
            mobileStyles.textContent = `
                .mobile-device .question {
                    margin-bottom: 1.5rem;
                    padding-bottom: 0.8rem;
                }
                
                .mobile-device .options label {
                    padding: 8px 0;
                }
                
                .mobile-device .options input[type="radio"] {
                    transform: scale(1.3);
                    margin-right: 10px;
                }
                
                .mobile-device .timer {
                    font-size: 1.2rem;
                }
                
                .mobile-device .primary-button, 
                .mobile-device .secondary-button {
                    padding: 12px 20px;
                    font-size: 1.1rem;
                }
            `;
            document.head.appendChild(mobileStyles);
            
            // Ajustar comportamiento de grabación para dispositivos móviles
            const startRecordingBtn = document.getElementById('start-recording');
            if (startRecordingBtn) {
                startRecordingBtn.addEventListener('touchstart', function(e) {
                    // Prevenir comportamiento táctil no deseado
                    e.preventDefault();
                });
            }
        }
    }
    
    // Compatibilidad con navegadores
    function ensureBrowserCompatibility() {
        // Detectar navegador
        const isIE = /*@cc_on!@*/false || !!document.documentMode;
        const isEdge = !isIE && !!window.StyleMedia;
        const isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);
        const isFirefox = typeof InstallTrigger !== 'undefined';
        const isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));
        
        // Añadir clase al body para estilos específicos por navegador
        if (isIE) document.body.classList.add('browser-ie');
        if (isEdge) document.body.classList.add('browser-edge');
        if (isChrome) document.body.classList.add('browser-chrome');
        if (isFirefox) document.body.classList.add('browser-firefox');
        if (isSafari) document.body.classList.add('browser-safari');
        
        // Polyfills y ajustes para navegadores antiguos
        if (!Element.prototype.closest) {
            Element.prototype.closest = function(s) {
                var el = this;
                do {
                    if (el.matches(s)) return el;
                    el = el.parentElement || el.parentNode;
                } while (el !== null && el.nodeType === 1);
                return null;
            };
        }
        
        // Advertencia para navegadores no compatibles
        if (isIE) {
            const warningDiv = document.createElement('div');
            warningDiv.style.cssText = 'background-color: #f8d7da; color: #721c24; padding: 10px; text-align: center; font-weight: bold;';
            warningDiv.textContent = 'Este navegador puede no ser totalmente compatible con todas las funciones. Recomendamos usar Chrome, Firefox, o Edge para una mejor experiencia.';
            document.body.insertBefore(warningDiv, document.body.firstChild);
        }
    }
    
    // Optimización de rendimiento
    function optimizePerformance() {
        // Debounce para funciones que se ejecutan frecuentemente
        function debounce(func, wait) {
            let timeout;
            return function() {
                const context = this, args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(context, args), wait);
            };
        }
        
        // Aplicar debounce a eventos de entrada de texto
        const textareas = document.querySelectorAll('textarea');
        textareas.forEach(textarea => {
            const originalInputHandler = textarea.oninput;
            if (originalInputHandler) {
                textarea.oninput = debounce(function(e) {
                    originalInputHandler.call(this, e);
                }, 100);
            }
        });
        
        // Reducir reflow y repaint
        const style = document.createElement('style');
        style.textContent = `
            .hardware-accelerated {
                transform: translateZ(0);
                will-change: transform;
            }
        `;
        document.head.appendChild(style);
        
        // Aplicar aceleración por hardware a elementos animados
        document.querySelectorAll('.progress, .recording-status.recording').forEach(el => {
            el.classList.add('hardware-accelerated');
        });
    }
    
    // Integración con Wix
    function enhanceWixIntegration() {
        // Comunicación con el contenedor Wix
        window.addEventListener('message', function(event) {
            // Verificar origen para seguridad
            if (event.origin !== 'https://www.englishabilitycanada.com' && 
                event.origin !== 'https://editor.wix.com') {
                return;
            }
            
            // Procesar mensajes del contenedor Wix
            if (event.data && event.data.type === 'wix-resize') {
                // Ajustar tamaño según instrucciones de Wix
                console.log('Recibido mensaje de redimensionamiento de Wix');
            }
            
            if (event.data && event.data.type === 'wix-navigate') {
                // Navegar a una sección específica
                const sectionId = event.data.sectionId;
                const navLinks = document.querySelectorAll('nav a');
                navLinks.forEach(link => {
                    if (link.getAttribute('data-section') === sectionId) {
                        link.click();
                    }
                });
            }
        });
        
        // Notificar al contenedor Wix cuando la aplicación esté lista
        window.parent.postMessage({ type: 'celpip-app-ready' }, '*');
        
        // Notificar al contenedor Wix cuando se completa la evaluación
        const downloadResultsBtn = document.getElementById('download-results');
        if (downloadResultsBtn) {
            downloadResultsBtn.addEventListener('click', function() {
                window.parent.postMessage({ 
                    type: 'celpip-assessment-complete',
                    result: window.userData.overall.level
                }, '*');
            });
        }
    }
    
    // Ejecutar todas las mejoras
    lazyLoadResources();
    enhanceAccessibility();
    optimizeForMobile();
    ensureBrowserCompatibility();
    optimizePerformance();
    enhanceWixIntegration();
    
    console.log('Mejoras de rendimiento y compatibilidad aplicadas');
});
