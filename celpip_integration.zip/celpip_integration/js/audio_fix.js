// Archivo de corrección para problemas de audio en navegadores
document.addEventListener('DOMContentLoaded', function() {
    // Solución para problemas de reproducción de audio en Safari
    const audioElements = document.querySelectorAll('audio');
    
    audioElements.forEach(audio => {
        // Forzar la precarga de audio
        audio.load();
        
        // Solución para problemas de reproducción en iOS
        audio.addEventListener('play', function() {
            // Algunos navegadores requieren interacción del usuario antes de reproducir audio
            // Este evento asegura que el audio se reproduzca correctamente después de la interacción
            if (audio.paused) {
                audio.play().catch(error => {
                    console.error('Error al reproducir audio:', error);
                });
            }
        });
        
        // Manejar errores de audio
        audio.addEventListener('error', function(e) {
            console.error('Error de audio:', e);
            // Intentar cargar nuevamente
            setTimeout(() => {
                audio.load();
            }, 1000);
        });
    });
    
    // Solución para problemas de grabación en algunos navegadores
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // El navegador soporta getUserMedia
        console.log('getUserMedia soportado');
    } else {
        console.error('getUserMedia no soportado en este navegador');
        // Mostrar mensaje al usuario
        const recordingElements = document.querySelectorAll('.recording-container');
        recordingElements.forEach(el => {
            el.innerHTML = '<p class="error-message">La grabación de audio no está soportada en este navegador. Por favor, utilice Chrome, Firefox o Edge.</p>';
        });
    }
});
