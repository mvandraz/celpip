document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navLinks = document.querySelectorAll('nav a');
    const sections = document.querySelectorAll('main section');
    const startAssessmentBtn = document.getElementById('start-assessment');
   
    // Section navigation buttons
    const readingNextBtn = document.getElementById('reading-next');
    const listeningNextBtn = document.getElementById('listening-next');
    const writingNextBtn = document.getElementById('writing-next');
    const speakingNextBtn = document.getElementById('speaking-next');
   
    // Results
    const downloadResultsBtn = document.getElementById('download-results');
    const restartAssessmentBtn = document.getElementById('restart-assessment');
   
    // User data storage
    window.userData = {
        reading: {
            answers: {},
            score: 0,
            level: ''
        },
        listening: {
            answers: {},
            score: 0,
            level: ''
        },
        writing: {
            text: '',
            score: 0,
            level: ''
        },
        speaking: {
            audioBlob: null,
            metrics: {},
            score: 0,
            level: ''
        },
        overall: {
            score: 0,
            level: ''
        }
    };
   
    // Initialize section visibility
    function showSection(sectionId) {
        sections.forEach(section => {
            section.classList.remove('active');
        });
       
        document.getElementById(sectionId).classList.add('active');
       
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-section') === sectionId) {
                link.classList.add('active');
            }
        });
       
        // Update progress bars
        updateProgress();
    }
   
    // Navigation event listeners
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.getAttribute('data-section');
            showSection(sectionId);
        });
    });
   
    // Start assessment button
    startAssessmentBtn.addEventListener('click', function() {
        showSection('reading');
        startReadingTimer();
    });
   
    // Section navigation
    readingNextBtn.addEventListener('click', function() {
        saveReadingAnswers();
        showSection('listening');
    });
   
    listeningNextBtn.addEventListener('click', function() {
        saveListeningAnswers();
        showSection('writing');
        startWritingTimer();
    });
   
    writingNextBtn.addEventListener('click', function() {
        saveWritingResponse();
        showSection('speaking');
    });
   
    speakingNextBtn.addEventListener('click', function() {
        saveSpeakingResponse();
        calculateResults();
        showSection('results');
    });
   
    // Results buttons
    downloadResultsBtn.addEventListener('click', function() {
        generatePDF();
    });
   
    restartAssessmentBtn.addEventListener('click', function() {
        resetAssessment();
        showSection('welcome');
    });
   
    // Reading section timer
    let readingTimeLeft = 90; // 1.5 minutes
    let readingTimerInterval;
   
    function startReadingTimer() {
        updateReadingTimer();
        readingTimerInterval = setInterval(function() {
            readingTimeLeft--;
            updateReadingTimer();
           
            if (readingTimeLeft <= 0) {
                clearInterval(readingTimerInterval);
                saveReadingAnswers();
                showSection('listening');
            }
        }, 1000);
    }
   
    function updateReadingTimer() {
        const minutes = Math.floor(readingTimeLeft / 60);
        const seconds = readingTimeLeft % 60;
        document.getElementById('reading-timer').textContent =
            'Time remaining: ' + minutes.toString().padStart(2, '0') + ':' +
            seconds.toString().padStart(2, '0');
    }
   
    // Writing section timer
    let writingTimeLeft = 90; // 1.5 minutes
    let writingTimerInterval;
   
    function startWritingTimer() {
        updateWritingTimer();
        writingTimerInterval = setInterval(function() {
            writingTimeLeft--;
            updateWritingTimer();
           
            if (writingTimeLeft <= 0) {
                clearInterval(writingTimerInterval);
                saveWritingResponse();
                showSection('speaking');
            }
        }, 1000);
    }
   
    function updateWritingTimer() {
        const minutes = Math.floor(writingTimeLeft / 60);
        const seconds = writingTimeLeft % 60;
        document.getElementById('writing-timer').textContent =
            'Time remaining: ' + minutes.toString().padStart(2, '0') + ':' +
            seconds.toString().padStart(2, '0');
    }
   
    // Word counter for writing section
    const writingResponse = document.getElementById('writing-response');
    const wordCounter = document.getElementById('word-counter');
   
    writingResponse.addEventListener('input', function() {
        const text = this.value;
        const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
        wordCounter.textContent = wordCount;
       
        // Visual feedback if over word limit
        if (wordCount > 100) {
            wordCounter.style.color = '#e74c3c';
        } else {
            wordCounter.style.color = '#7f8c8d';
        }
    });
   
    // Listening section audio controls
    const listeningAudio = document.getElementById('listening-audio');
    const playAudioBtn = document.getElementById('play-audio');
    const playCount = document.getElementById('play-count');
    let audioPlayCount = 0;
   
    playAudioBtn.addEventListener('click', function() {
        if (audioPlayCount < 2) {
            listeningAudio.play();
            audioPlayCount++;
            playCount.textContent = 'Plays: ' + audioPlayCount + '/2';
           
            if (audioPlayCount >= 2) {
                playAudioBtn.disabled = true;
            }
        }
    });
   
    listeningAudio.addEventListener('ended', function() {
        // Enable the next button after audio has been played at least once
        if (audioPlayCount > 0) {
            listeningNextBtn.disabled = false;
        }
    });
   
    // Speaking section recording functionality
    const startRecordingBtn = document.getElementById('start-recording');
    const stopRecordingBtn = document.getElementById('stop-recording');
    const recordingStatus = document.getElementById('recording-status');
    const speakingTimer = document.getElementById('speaking-timer');
    const recordedAudio = document.getElementById('recorded-audio');
   
    let mediaRecorder;
    let audioChunks = [];
    let speakingTimeLeft = 30; // 30 seconds
    let speakingTimerInterval;
   
    startRecordingBtn.addEventListener('click', function() {
        // Request microphone access
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                audioChunks = [];
                mediaRecorder = new MediaRecorder(stream);
               
                mediaRecorder.addEventListener('dataavailable', event => {
                    audioChunks.push(event.data);
                });
               
                mediaRecorder.addEventListener('stop', () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                    const audioUrl = URL.createObjectURL(audioBlob);
                    recordedAudio.src = audioUrl;
                    window.userData.speaking.audioBlob = audioBlob;
                   
                    // Enable playback and next button
                    recordedAudio.style.display = 'block';
                    speakingNextBtn.disabled = false;
                   
                    // Stop all tracks from the stream to release the microphone
                    stream.getTracks().forEach(track => track.stop());
                });
               
                // Start recording
                mediaRecorder.start();
                recordingStatus.textContent = 'Recording...';
                recordingStatus.classList.add('recording');
                startRecordingBtn.disabled = true;
                stopRecordingBtn.disabled = false;
               
                // Start timer
                speakingTimeLeft = 30;
                updateSpeakingTimer();
                speakingTimerInterval = setInterval(function() {
                    speakingTimeLeft--;
                    updateSpeakingTimer();
                   
                    if (speakingTimeLeft <= 0) {
                        stopRecording();
                    }
                }, 1000);
            })
            .catch(error => {
                console.error('Error accessing microphone:', error);
                recordingStatus.textContent = 'Error: Could not access microphone';
            });
    });
   
    stopRecordingBtn.addEventListener('click', function() {
        stopRecording();
    });
   
    function stopRecording() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            clearInterval(speakingTimerInterval);
            recordingStatus.textContent = 'Recording complete';
            recordingStatus.classList.remove('recording');
            startRecordingBtn.disabled = false;
            stopRecordingBtn.disabled = true;
        }
    }
   
    function updateSpeakingTimer() {
        const seconds = speakingTimeLeft % 60;
        speakingTimer.textContent = '00:' + seconds.toString().padStart(2, '0');
    }
   
    // Save user responses
    function saveReadingAnswers() {
        clearInterval(readingTimerInterval);
       
        // Get all reading question answers
        const readingQuestions = document.querySelectorAll('[id^="reading-q"]');
        readingQuestions.forEach(question => {
            const questionId = question.id;
            const selectedOption = document.querySelector('input[name="' + questionId + '"]:checked');
           
            if (selectedOption) {
                window.userData.reading.answers[questionId] = selectedOption.value;
            }
        });
       
        // Calculate reading score
        evaluateReadingAnswers();
    }
   
    function saveListeningAnswers() {
        // Get all listening question answers
        const listeningQuestions = document.querySelectorAll('[id^="listening-q"]');
        listeningQuestions.forEach(question => {
            const questionId = question.id;
            const selectedOption = document.querySelector('input[name="' + questionId + '"]:checked');
           
            if (selectedOption) {
                window.userData.listening.answers[questionId] = selectedOption.value;
            }
        });
       
        // Calculate listening score
        evaluateListeningAnswers();
    }
   
    function saveWritingResponse() {
        clearInterval(writingTimerInterval);
       
        // Get writing response
        const writingText = document.getElementById('writing-response').value;
        window.userData.writing.text = writingText;
       
        // Calculate writing score
        evaluateWritingResponse();
    }
   
    function saveSpeakingResponse() {
        // Speaking response is already saved when recording is stopped
        // Calculate speaking score
        evaluateSpeakingResponse();
    }
   
    // Evaluation functions
    function evaluateReadingAnswers() {
        // Correct answers
        const correctAnswers = {
            'reading-q1': 'c', // 82%
            'reading-q2': 'd', // Increased transportation costs
            'reading-q3': 'b'  // 72%
        };
       
        let score = 0;
        let totalQuestions = Object.keys(correctAnswers).length;
       
        // Compare user answers with correct answers
        for (const questionId in correctAnswers) {
            if (window.userData.reading.answers[questionId] === correctAnswers[questionId]) {
                score++;
            }
        }
       
        // Calculate percentage and assign level
        const percentage = (score / totalQuestions) * 100;
        window.userData.reading.score = percentage;
        window.userData.reading.level = assignLevel(percentage);
       
        // Update progress bar
        document.getElementById('reading-progress').style.width = '100%';
    }
   
    function evaluateListeningAnswers() {
        // Correct answers (these would be based on the actual audio content)
        const correctAnswers = {
            'listening-q1': 'b', // A community garden project
            'listening-q2': 'a', // This Saturday morning
            'listening-q3': 'b'  // Gardening tools
        };
       
        let score = 0;
        let totalQuestions = Object.keys(correctAnswers).length;
       
        // Compare user answers with correct answers
        for (const questionId in correctAnswers) {
            if (window.userData.listening.answers[questionId] === correctAnswers[questionId]) {
                score++;
            }
        }
       
        // Calculate percentage and assign level
        const percentage = (score / totalQuestions) * 100;
        window.userData.listening.score = percentage;
        window.userData.listening.level = assignLevel(percentage);
       
        // Update progress bar
        document.getElementById('listening-progress').style.width = '100%';
    }
   
    function evaluateWritingResponse() {
        // Simple evaluation based on word count
        const text = window.userData.writing.text;
        const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
       
        let percentage = 0;
       
        if (wordCount >= 50 && wordCount <= 100) {
            // Full points for meeting word count requirements
            percentage = 80;
            
            // Additional points for using complex vocabulary and grammar
            // This is a simplified simulation - in a real system, NLP would be used
            const complexWords = ['implement', 'flexibility', 'productivity', 'beneficial', 'environment'];
            let complexWordCount = 0;
            
            complexWords.forEach(word => {
                if (text.toLowerCase().includes(word.toLowerCase())) {
                    complexWordCount++;
                }
            });
            
            percentage += complexWordCount * 4; // Up to 20% more for vocabulary
            if (percentage > 100) percentage = 100;
        } else if (wordCount > 0) {
            // Partial points for writing something but not meeting requirements
            percentage = 50;
        }
       
        window.userData.writing.score = percentage;
        window.userData.writing.level = assignLevel(percentage);
       
        // Update progress bar
        document.getElementById('writing-progress').style.width = '100%';
    }
   
    function evaluateSpeakingResponse() {
        // In a real system, this would use speech recognition and analysis
        // For this demo, we'll simulate a score
        
        // Check if user recorded audio
        if (window.userData.speaking.audioBlob) {
            // Simulate metrics that would come from speech analysis
            window.userData.speaking.metrics = {
                pronunciation: Math.floor(Math.random() * 30) + 70, // 70-100
                fluency: Math.floor(Math.random() * 30) + 70,
                vocabulary: Math.floor(Math.random() * 30) + 70,
                grammar: Math.floor(Math.random() * 30) + 70
            };
            
            // Calculate average score
            const metrics = window.userData.speaking.metrics;
            const average = (metrics.pronunciation + metrics.fluency + 
                            metrics.vocabulary + metrics.grammar) / 4;
            
            window.userData.speaking.score = average;
            window.userData.speaking.level = assignLevel(average);
        } else {
            // No recording
            window.userData.speaking.score = 0;
            window.userData.speaking.level = 'N/A';
        }
       
        // Update progress bar
        document.getElementById('speaking-progress').style.width = '100%';
    }
   
    // Calculate overall results
    function calculateResults() {
        // Calculate overall score as average of all sections
        const readingScore = window.userData.reading.score || 0;
        const listeningScore = window.userData.listening.score || 0;
        const writingScore = window.userData.writing.score || 0;
        const speakingScore = window.userData.speaking.score || 0;
       
        const overallScore = (readingScore + listeningScore + writingScore + speakingScore) / 4;
        window.userData.overall.score = overallScore;
        window.userData.overall.level = assignLevel(overallScore);
       
        // Display results
        displayResults();
    }
   
    // Assign proficiency level based on score
    function assignLevel(score) {
        if (score >= 90) return 'C2';
        if (score >= 80) return 'C1';
        if (score >= 70) return 'B2';
        if (score >= 60) return 'B1';
        if (score >= 50) return 'A2';
        if (score > 0) return 'A1';
        return 'N/A';
    }
   
    // Display results
    function displayResults() {
        // Overall score
        const overallLevel = window.userData.overall.level;
        document.getElementById('overall-level').textContent = overallLevel;
        document.getElementById('overall-score-circle').className = 'score-circle level-' + overallLevel.toLowerCase();
       
        // Individual scores
        const sections = ['reading', 'listening', 'writing', 'speaking'];
        sections.forEach(section => {
            const score = window.userData.[section].score;
            const level = window.userData.[section].level;
           
            document.getElementById(section + '-score').textContent = level;
            document.getElementById(section + '-score-bar').style.width = score + '%';
            document.getElementById(section + '-score-bar').className = 'score-bar level-' + level.toLowerCase();
        });
       
        // Level description
        const levelDescriptions = {
            'C2': 'Proficient User: You have full command of the language with complete fluency and accuracy.',
            'C1': 'Advanced User: You can use English fluently and effectively for social, academic, and professional purposes.',
            'B2': 'Upper Intermediate User: You can interact with a degree of fluency and spontaneity with native speakers.',
            'B1': 'Intermediate User: You can deal with most situations likely to arise while traveling in an area where English is spoken.',
            'A2': 'Elementary User: You can communicate in simple and routine tasks requiring a simple exchange of information.',
            'A1': 'Beginner User: You can understand and use familiar everyday expressions and very basic phrases.',
            'N/A': 'Not Available: Complete all sections of the assessment to see your results.'
        };
       
        document.getElementById('level-description').innerHTML = 
            '<p><strong>' + overallLevel + ':</strong> ' + levelDescriptions[overallLevel] + '</p>';
    }
   
    // Generate PDF report
    function generatePDF() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Add title
        doc.setFontSize(20);
        doc.text('CELPIP English Assessment Results', 105, 20, { align: 'center' });
        
        // Add date
        doc.setFontSize(12);
        const today = new Date();
        doc.text('Date: ' + today.toLocaleDateString(), 20, 30);
        
        // Overall score
        doc.setFontSize(16);
        doc.text('Overall Proficiency Level: ' + window.userData.overall.level, 20, 45);
        
        // Individual scores
        doc.setFontSize(14);
        doc.text('Skill Breakdown:', 20, 60);
        
        const sections = [
            { name: 'Reading', y: 70 },
            { name: 'Listening', y: 80 },
            { name: 'Writing', y: 90 },
            { name: 'Speaking', y: 100 }
        ];
        
        sections.forEach(section => {
            const sectionKey = section.name.toLowerCase();
            const level = window.userData.[sectionKey].level;
            const score = Math.round(window.userData.[sectionKey].score);
            
            doc.text(section.name + ': ' + level + ' (' + score + '%)', 30, section.y);
        });
        
        // Level description
        doc.setFontSize(14);
        doc.text('What Your Level Means:', 20, 115);
        
        const levelDescriptions = {
            'C2': 'Proficient User: Full command of the language with complete fluency and accuracy.',
            'C1': 'Advanced User: Fluent and effective use of English for social, academic, and professional purposes.',
            'B2': 'Upper Intermediate User: Interaction with fluency and spontaneity with native speakers.',
            'B1': 'Intermediate User: Can deal with most situations in English-speaking environments.',
            'A2': 'Elementary User: Can communicate in simple and routine tasks.',
            'A1': 'Beginner User: Can understand and use familiar everyday expressions and basic phrases.',
            'N/A': 'Not Available: Complete all sections of the assessment to see your results.'
        };
        
        const description = levelDescriptions[window.userData.overall.level];
        doc.setFontSize(12);
        
        // Split long text into multiple lines
        const splitText = doc.splitTextToSize(description, 170);
        doc.text(splitText, 30, 125);
        
        // Footer
        doc.setFontSize(10);
        doc.text('© 2025 CELPIP English Assessment. All rights reserved.', 105, 280, { align: 'center' });
        
        // Save PDF
        doc.save('CELPIP_Assessment_Results.pdf');
    }
   
    // Reset assessment
    function resetAssessment() {
        // Reset user data
        window.userData = {
            reading: { answers: {}, score: 0, level: '' },
            listening: { answers: {}, score: 0, level: '' },
            writing: { text: '', score: 0, level: '' },
            speaking: { audioBlob: null, metrics: {}, score: 0, level: '' },
            overall: { score: 0, level: '' }
        };
        
        // Reset UI elements
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.checked = false;
        });
        
        document.getElementById('writing-response').value = '';
        document.getElementById('word-counter').textContent = '0';
        
        document.getElementById('recorded-audio').style.display = 'none';
        document.getElementById('recorded-audio').src = '';
        
        // Reset timers
        readingTimeLeft = 90;
        writingTimeLeft = 90;
        
        // Reset progress bars
        document.querySelectorAll('.progress').forEach(bar => {
            bar.style.width = '0%';
        });
        
        // Reset buttons
        listeningNextBtn.disabled = true;
        speakingNextBtn.disabled = true;
        
        // Reset audio play count
        audioPlayCount = 0;
        document.getElementById('play-count').textContent = 'Plays: 0/2';
        document.getElementById('play-audio').disabled = false;
    }
   
    // Update progress bars based on current section
    function updateProgress() {
        const currentSection = document.querySelector('section.active').id;
        
        if (currentSection === 'reading') {
            document.getElementById('reading-progress').style.width = '25%';
        } else if (currentSection === 'listening') {
            document.getElementById('reading-progress').style.width = '100%';
            document.getElementById('listening-progress').style.width = '25%';
        } else if (currentSection === 'writing') {
            document.getElementById('reading-progress').style.width = '100%';
            document.getElementById('listening-progress').style.width = '100%';
            document.getElementById('writing-progress').style.width = '25%';
        } else if (currentSection === 'speaking') {
            document.getElementById('reading-progress').style.width = '100%';
            document.getElementById('listening-progress').style.width = '100%';
            document.getElementById('writing-progress').style.width = '100%';
            document.getElementById('speaking-progress').style.width = '25%';
        } else if (currentSection === 'results') {
            document.getElementById('reading-progress').style.width = '100%';
            document.getElementById('listening-progress').style.width = '100%';
            document.getElementById('writing-progress').style.width = '100%';
            document.getElementById('speaking-progress').style.width = '100%';
        }
    }
});
