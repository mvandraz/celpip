// Evaluación de la capacidad de habla
document.addEventListener('DOMContentLoaded', function() {
    // Variables para la evaluación del habla
    let speakingMetrics = {
        pronunciation: 0,
        fluency: 0,
        vocabulary: 0,
        grammar: 0
    };
    
    // Función para simular el análisis de audio
    window.analyzeSpeakingAudio = function(audioBlob) {
        return new Promise((resolve) => {
            // En un sistema real, esto enviaría el audio a un servicio de reconocimiento de voz
            // y analizaría la calidad del habla usando IA
            
            // Para esta demo, simulamos el proceso con un temporizador
            setTimeout(() => {
                // Generar métricas simuladas
                speakingMetrics = {
                    pronunciation: Math.floor(Math.random() * 30) + 70, // 70-100
                    fluency: Math.floor(Math.random() * 30) + 70,       // 70-100
                    vocabulary: Math.floor(Math.random() * 30) + 70,    // 70-100
                    grammar: Math.floor(Math.random() * 30) + 70        // 70-100
                };
                
                // Calcular puntuación promedio
                const averageScore = (speakingMetrics.pronunciation + 
                                     speakingMetrics.fluency + 
                                     speakingMetrics.vocabulary + 
                                     speakingMetrics.grammar) / 4;
                
                resolve({
                    metrics: speakingMetrics,
                    score: averageScore
                });
            }, 1500); // Simular tiempo de procesamiento
        });
    };
    
    // Función para asignar nivel basado en puntuación
    window.getSpeakingLevel = function(score) {
        if (score >= 90) return 'C2';
        if (score >= 80) return 'C1';
        if (score >= 70) return 'B2';
        if (score >= 60) return 'B1';
        if (score >= 50) return 'A2';
        if (score > 0) return 'A1';
        return 'N/A';
    };
    
    // Función para obtener retroalimentación basada en métricas
    window.getSpeakingFeedback = function(metrics) {
        let feedback = {
            strengths: [],
            improvements: []
        };
        
        // Analizar fortalezas (puntuaciones altas)
        if (metrics.pronunciation >= 85) {
            feedback.strengths.push('Excelente pronunciación y claridad.');
        }
        if (metrics.fluency >= 85) {
            feedback.strengths.push('Habla con fluidez natural y buen ritmo.');
        }
        if (metrics.vocabulary >= 85) {
            feedback.strengths.push('Uso de vocabulario variado y apropiado.');
        }
        if (metrics.grammar >= 85) {
            feedback.strengths.push('Buena estructura gramatical y precisión.');
        }
        
        // Analizar áreas de mejora (puntuaciones más bajas)
        if (metrics.pronunciation < 70) {
            feedback.improvements.push('Practicar la pronunciación de sonidos específicos del inglés.');
        }
        if (metrics.fluency < 70) {
            feedback.improvements.push('Trabajar en la fluidez y reducir las pausas.');
        }
        if (metrics.vocabulary < 70) {
            feedback.improvements.push('Ampliar el vocabulario para expresar ideas con más precisión.');
        }
        if (metrics.grammar < 70) {
            feedback.improvements.push('Revisar estructuras gramaticales básicas y tiempos verbales.');
        }
        
        return feedback;
    };
});
