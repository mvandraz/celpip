// Evaluación de la precisión de la prueba
document.addEventListener('DOMContentLoaded', function() {
    // Esta función simula la evaluación de la precisión de las respuestas
    // En un sistema real, esto se conectaría a un backend para análisis más sofisticados
    
    // Función para evaluar la precisión de la escritura
    window.evaluateWritingAccuracy = function(text) {
        if (!text || text.trim() === '') return 0;
        
        // Criterios de evaluación
        const criteria = {
            length: 0,           // Longitud adecuada
            relevance: 0,        // Relevancia al tema
            grammar: 0,          // Gramática correcta
            vocabulary: 0,       // Vocabulario apropiado
            structure: 0         // Estructura del texto
        };
        
        // Evaluar longitud
        const wordCount = text.trim().split(/\s+/).length;
        if (wordCount >= 50 && wordCount <= 100) {
            criteria.length = 20; // Puntuación máxima para longitud adecuada
        } else if (wordCount > 0) {
            criteria.length = Math.min(20, (wordCount / 50) * 20); // Puntuación proporcional
        }
        
        // Evaluar relevancia (simulada)
        // Buscar palabras clave relacionadas con el tema de trabajo flexible
        const relevanceKeywords = ['flexible', 'work', 'policy', 'benefits', 'productivity', 
                                  'balance', 'remote', 'schedule', 'efficiency', 'manager'];
        
        let keywordCount = 0;
        relevanceKeywords.forEach(keyword => {
            if (text.toLowerCase().includes(keyword.toLowerCase())) {
                keywordCount++;
            }
        });
        
        criteria.relevance = Math.min(20, (keywordCount / 5) * 20);
        
        // Evaluar gramática y vocabulario (simulado)
        // En un sistema real, esto usaría NLP
        criteria.grammar = Math.floor(Math.random() * 10) + 10; // 10-20 puntos
        criteria.vocabulary = Math.floor(Math.random() * 10) + 10; // 10-20 puntos
        
        // Evaluar estructura (simulado)
        // Verificar si tiene párrafos, saludo y cierre
        if (text.includes('\n\n') || text.includes('\r\n\r\n')) {
            criteria.structure += 10; // Tiene párrafos
        }
        
        if ((text.toLowerCase().includes('dear') || text.toLowerCase().includes('hello') || 
             text.toLowerCase().includes('hi')) && text.includes(',')) {
            criteria.structure += 5; // Tiene saludo
        }
        
        if (text.toLowerCase().includes('sincerely') || text.toLowerCase().includes('regards') || 
            text.toLowerCase().includes('thank you')) {
            criteria.structure += 5; // Tiene cierre
        }
        
        // Calcular puntuación total
        const total = criteria.length + criteria.relevance + criteria.grammar + 
                     criteria.vocabulary + criteria.structure;
        
        return total;
    };
    
    // Función para evaluar la precisión del habla
    window.evaluateSpeakingAccuracy = function(audioBlob) {
        // En un sistema real, esto enviaría el audio a un servicio de reconocimiento de voz
        // y analizaría la calidad del habla
        
        // Para esta demo, generamos métricas simuladas
        const metrics = {
            pronunciation: Math.floor(Math.random() * 30) + 70, // 70-100
            fluency: Math.floor(Math.random() * 30) + 70,       // 70-100
            vocabulary: Math.floor(Math.random() * 30) + 70,    // 70-100
            grammar: Math.floor(Math.random() * 30) + 70        // 70-100
        };
        
        return metrics;
    };
});
