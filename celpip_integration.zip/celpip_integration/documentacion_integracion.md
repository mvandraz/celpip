# Documentación de Integración: Evaluación CELPIP en Sitio Wix

## Índice
1. [Introducción](#introducción)
2. [Estructura de Archivos](#estructura-de-archivos)
3. [Opciones de Integración](#opciones-de-integración)
4. [Guía de Implementación](#guía-de-implementación)
5. [Consideraciones Técnicas](#consideraciones-técnicas)
6. [Solución de Problemas](#solución-de-problemas)
7. [Mejoras Implementadas](#mejoras-implementadas)
8. [Mantenimiento](#mantenimiento)

## Introducción

Este documento describe el proceso completo para integrar la aplicación de evaluación CELPIP en el sitio web de English Ability Canada, construido con Wix. La aplicación permite a los usuarios realizar una evaluación de sus habilidades en inglés en cuatro áreas: lectura, escucha, escritura y habla.

La integración se ha diseñado considerando las limitaciones y capacidades de la plataforma Wix, ofreciendo varias opciones para adaptarse a las necesidades específicas del cliente.

## Estructura de Archivos

La aplicación CELPIP está compuesta por los siguientes archivos:

```
celpip_integration/
├── html/
│   ├── celpip_assessment.html       # Aplicación principal
│   ├── responsive_iframe.html       # Contenedor responsivo
│   └── wix_integration_guide.html   # Guía visual de integración
├── css/
│   └── styles.css                   # Estilos de la aplicación
├── js/
│   ├── script.js                    # Funcionalidad principal
│   ├── audio_fix.js                 # Correcciones para audio
│   ├── speaking_evaluation.js       # Evaluación de habla
│   ├── evaluation_accuracy.js       # Precisión de evaluación
│   └── performance_enhancements.js  # Mejoras de rendimiento
└── audio/
    └── listening_test.mp3           # Audio de muestra
```

## Opciones de Integración

Se han desarrollado tres opciones principales para integrar la aplicación en el sitio Wix:

### 1. Elemento HTML Personalizado

Esta opción utiliza el elemento HTML personalizado de Wix para incrustar la aplicación directamente en una página existente.

**Ventajas:**
- Mantiene la navegación y el diseño del sitio Wix
- Permite a los usuarios permanecer en el mismo dominio
- Fácil de implementar sin conocimientos técnicos avanzados

**Desventajas:**
- Limitaciones de espacio según el diseño de la página
- Posibles conflictos con estilos o scripts de Wix

### 2. Botón de Redirección

Esta opción añade un botón en el sitio Wix que redirige a los usuarios a la página de la aplicación CELPIP alojada externamente.

**Ventajas:**
- Implementación muy sencilla
- Sin problemas de compatibilidad
- Experiencia de usuario más inmersiva al usar la aplicación en una página dedicada

**Desventajas:**
- Los usuarios salen del sitio principal
- Posible pérdida de contexto de marca

### 3. Página Dedicada con Iframe

Esta opción crea una página completa en el sitio Wix dedicada a la evaluación CELPIP, utilizando un iframe a pantalla completa.

**Ventajas:**
- Mantiene a los usuarios en el dominio del sitio
- Experiencia inmersiva sin distracciones
- Mejor rendimiento al estar aislada del resto del sitio

**Desventajas:**
- Requiere crear y configurar una nueva página en Wix
- Posibles limitaciones con permisos de micrófono en algunos navegadores

## Guía de Implementación

### Opción 1: Elemento HTML Personalizado

1. En el editor de Wix, añade un nuevo elemento "HTML personalizado" (desde el menú + → Más → HTML personalizado)
2. Pega el siguiente código en el cuadro de HTML:

```html
<div id="celpip-assessment-container" style="width:100%; height:800px;">
    <iframe 
        src="URL_DE_TU_APLICACION_CELPIP" 
        style="width:100%; height:100%; border:none;"
        allow="microphone; camera"
        allowfullscreen>
    </iframe>
</div>
```

3. Reemplaza "URL_DE_TU_APLICACION_CELPIP" con la URL donde esté alojada la aplicación CELPIP
4. Ajusta el alto (height) según sea necesario para tu diseño

### Opción 2: Botón de Redirección

1. En el editor de Wix, añade un botón a la página donde quieras colocar el acceso a la evaluación
2. Personaliza el botón con el texto "Realizar Evaluación CELPIP" y los colores que coincidan con el diseño del sitio
3. En las configuraciones del botón, selecciona "Enlace" y luego "URL web"
4. Introduce la URL donde esté alojada la aplicación CELPIP
5. Opcionalmente, marca la opción "Abrir en una nueva pestaña"

Para un botón personalizado con HTML:

```html
<div id="celpip-button-container">
    <a href="URL_DE_TU_APLICACION_CELPIP" target="_blank" class="celpip-button">Realizar Evaluación CELPIP</a>
    <style>
        .celpip-button {
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            font-size: 18px;
            transition: background-color 0.3s, transform 0.2s;
        }
        .celpip-button:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
    </style>
</div>
```

### Opción 3: Página Dedicada con Iframe

1. En el panel de control de Wix, crea una nueva página (por ejemplo, "Evaluación CELPIP")
2. Añade un elemento HTML personalizado que ocupe la mayor parte de la página
3. Pega el siguiente código en el cuadro de HTML:

```html
<div id="celpip-full-page" style="width:100%; min-height:800px; margin-top:-40px;">
    <iframe 
        src="URL_DE_TU_APLICACION_CELPIP" 
        style="width:100%; height:100vh; border:none; overflow:hidden;"
        allow="microphone; camera"
        allowfullscreen>
    </iframe>
    <style>
        /* Ocultar elementos de navegación de Wix en esta página */
        .site-header, .site-footer {
            display: none !important;
        }
        body {
            overflow: hidden;
        }
    </style>
</div>
```

4. Reemplaza "URL_DE_TU_APLICACION_CELPIP" con la URL donde esté alojada la aplicación CELPIP
5. Ajusta los estilos según sea necesario para tu diseño

## Consideraciones Técnicas

### Alojamiento de la Aplicación

La aplicación CELPIP debe estar alojada en un servidor accesible públicamente. Opciones recomendadas:

1. **Servicio de alojamiento web estándar**: Subir los archivos a un hosting compartido o VPS
2. **Servicios de alojamiento estático**: GitHub Pages, Netlify, Vercel
3. **Almacenamiento en la nube**: Amazon S3, Google Cloud Storage con configuración de sitio web estático

### Permisos de Micrófono

Para que funcione la sección de habla, el navegador debe tener acceso al micrófono del usuario. Esto requiere:

1. Que la aplicación se sirva a través de HTTPS (conexión segura)
2. Incluir el atributo `allow="microphone"` en el iframe
3. El usuario debe dar permiso cuando el navegador lo solicite

### Compatibilidad con Navegadores

La aplicación ha sido optimizada para funcionar en:
- Chrome 70+
- Firefox 63+
- Safari 12+
- Edge 79+

Se han implementado polyfills y correcciones para mejorar la compatibilidad con navegadores más antiguos, pero algunas funcionalidades como la grabación de audio pueden no funcionar correctamente en navegadores obsoletos.

### Responsividad

La aplicación está diseñada para adaptarse a diferentes tamaños de pantalla:
- Escritorio (1024px y superior)
- Tablet (768px - 1023px)
- Móvil (menos de 768px)

El archivo `responsive_iframe.html` proporciona un contenedor que ajusta automáticamente las proporciones según el dispositivo.

## Solución de Problemas

### El audio no se reproduce

**Posibles causas y soluciones:**
- El navegador bloquea la reproducción automática: Añadir interacción del usuario antes de reproducir audio
- Formato de audio no compatible: Asegurarse de que el archivo MP3 esté correctamente codificado
- Ruta incorrecta: Verificar que la ruta al archivo de audio sea correcta

### La grabación de audio no funciona

**Posibles causas y soluciones:**
- Permisos de micrófono denegados: El usuario debe permitir el acceso al micrófono
- Conexión no segura: Asegurarse de que la aplicación se sirve a través de HTTPS
- Navegador no compatible: Recomendar al usuario utilizar un navegador moderno

### Problemas de visualización en Wix

**Posibles causas y soluciones:**
- Conflictos de CSS: Aislar los estilos de la aplicación dentro del iframe
- Tamaño incorrecto del contenedor: Ajustar las dimensiones del iframe
- Elementos superpuestos: Verificar el z-index y la posición de los elementos

## Mejoras Implementadas

### Optimización de Rendimiento

- **Carga diferida de recursos**: Los archivos de audio se cargan solo cuando son necesarios
- **Debouncing de eventos**: Reducción de llamadas a funciones en eventos frecuentes
- **Aceleración por hardware**: Uso de propiedades CSS para mejorar el rendimiento de animaciones

### Accesibilidad

- **Atributos ARIA**: Mejora de la experiencia para usuarios con lectores de pantalla
- **Contraste mejorado**: Colores optimizados para mejor legibilidad
- **Navegación por teclado**: Mejora del enfoque visual para usuarios que navegan sin ratón

### Compatibilidad con Dispositivos Móviles

- **Diseño responsivo**: Adaptación a diferentes tamaños de pantalla
- **Optimización táctil**: Botones más grandes y espaciados para facilitar la interacción
- **Ajustes específicos**: Estilos y comportamientos adaptados para dispositivos móviles

### Integración con Wix

- **Comunicación bidireccional**: La aplicación puede enviar y recibir mensajes del contenedor Wix
- **Notificaciones de eventos**: Informes de estado y resultados al sitio principal
- **Ajustes automáticos**: Adaptación a cambios en el entorno de Wix

## Mantenimiento

### Actualizaciones Recomendadas

- **Contenido de evaluación**: Actualizar periódicamente las preguntas y pasajes de lectura
- **Archivos de audio**: Reemplazar con grabaciones profesionales para la sección de escucha
- **Algoritmos de evaluación**: Mejorar la precisión de la evaluación con datos reales

### Monitoreo

- **Compatibilidad con navegadores**: Verificar regularmente el funcionamiento en nuevas versiones
- **Rendimiento**: Analizar tiempos de carga y respuesta
- **Experiencia de usuario**: Recopilar comentarios para identificar áreas de mejora

### Copias de Seguridad

Se recomienda mantener copias de seguridad de todos los archivos de la aplicación, especialmente antes de realizar actualizaciones o modificaciones.
